package edu.neo.saludable.model

class Paciente {
}