package edu.neo.saludable.view

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ComidaActivity : AppCompatActivity() {

    lateinit var comidas: Spinner
    lateinit var principal: EditText
    lateinit var secundaria: EditText
    lateinit var bebida: EditText
    lateinit var ingirioPostre: RadioGroup
    lateinit var postreSi: RadioButton
    lateinit var postreNo: RadioButton
    lateinit var postre: EditText
    lateinit var seTento: RadioGroup
    lateinit var tentacionSi: RadioButton
    lateinit var tentacionNo: RadioButton
    lateinit var tentacion: EditText
    lateinit var hambre: Switch
    lateinit var fecha: EditText
    lateinit var hora: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comida)
    }


    private fun inicializar(){
        comidas = findViewByid(R.d.r)
        principal: EditText
        secundaria: EditText
        bebida: EditText
        ingirioPostre: RadioGroup
        postreSi: RadioButton
        postreNo: RadioButton
        postre: EditText
        seTento: RadioGroup
        ltentacionSi: RadioButton
        tentacionNo: RadioButton
        tentacion: EditText
        hambre: Switch
        fecha: EditText
        hora: EditText

    }
}